//
//  ViewController.m
//  Table View
//
//  Created by Abhijit Kotangale on 8/10/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"

@interface ViewController (){
    NSArray *name;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    name = @[@"First Name", @"Second Name", @"Third Name", @"Fourth Name", @"Fifth Name"];
    
    _tblView.dataSource = self;
    _tblView.dataSource = self;
    [_tblView reloadData];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return name.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CustomTableViewCell *cell = [_tblView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.lblName.text = [name objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
