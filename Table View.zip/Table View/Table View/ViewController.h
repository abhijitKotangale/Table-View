//
//  ViewController.h
//  Table View
//
//  Created by Abhijit Kotangale on 8/10/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>


@property (weak, nonatomic) IBOutlet UITableView *tblView;

@end

