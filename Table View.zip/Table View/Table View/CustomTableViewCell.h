//
//  CustomTableViewCell.h
//  Table View
//
//  Created by Abhijit Kotangale on 8/10/17.
//  Copyright © 2017 Abhijit Kotangale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblName;

@end
